#include <stdio.h>
#include <pthread.h>

// Define struct
typedef struct {
    int student_id;
    char name[50];
    float gpa;
} Student;

int dean_count = 0;  // Shared variable

// Thread function
void* check_dean(void* arg) {
    Student* s = (Student*)arg;

    printf("\nStudent ID: %d\nName: %s\nGPA: %.2f\n", s->student_id, s->name, s->gpa);

    if (s->gpa >= 3.5) {
        printf("%s made the Dean's List!\n", s->name);
        dean_count++;
    } else {
        printf("%s did not make the Dean's List.\n", s->name);
    }

    return NULL;
}

int main() {
    pthread_t t1, t2, t3;

    // Create students
    Student s1 = {101, "Alice", 3.8};
    Student s2 = {102, "Bob", 3.2};
    Student s3 = {103, "Charlie", 3.9};

    // Create threads
    pthread_create(&t1, NULL, check_dean, &s1);
    pthread_create(&t2, NULL, check_dean, &s2);
    pthread_create(&t3, NULL, check_dean, &s3);

    // Wait for threads to finish
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    // Final result
    printf("\nTotal students on Dean's List: %d\n", dean_count);

    return 0;
}
