echo 'Hello World'
pwd
-ls -lh
